<script type="text/javascript">
    var public_lang = "{{ trans('backLang.calendarLanguage') }}"; // this is a public var used in app.html.js to define path to js files
    var public_folder_path = "{{ URL::to('') }}"; // this is a public var used in app.html.js to define path to js files
</script>
<script src="{{ URL::to('backEnd/scripts/app.html.js') }}"></script>
<script src="{{ URL::to('backEnd/scripts/jscolor.js') }}"></script>
{!! \App\Helpers\Helper::SaveVisitorInfo("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]") !!}


<script type="text/javascript">
    $(document).ready(function () {
        // $( "#section_id" ).hide();
        // $( "#section_id2" ).show();

  $("select[name='type_id']").change(function(){
      var type_id = $(this).val();

      $.ajax({
          url: '{{url("get/cate")}}'+'/'+type_id,
          method: 'get',
          success: function(data) {
              console.log(data);
             $("select[name='section_id'").html('');
            $("select[name='section_id'").html(data.options);

          }
      });
  });
  
    $("select[name='section_id']").change(function(){
      var sub_id = $(this).val();
    //  alert(sub_id);
      $.ajax({
          url: '{{url("get/subcate")}}'+'/'+sub_id,
          method: 'get',
          success: function(data) {
              console.log(data);
             $("select[name='subcate_id'").html('');
            $("select[name='subcate_id'").html(data.options);

          }
      });
  });
  
      $("select[name='subcate_id']").change(function(){
      var pro_id = $(this).val();
    //  alert(pro_id);
      $.ajax({
          url: '{{url("get/product")}}'+'/'+pro_id,
          method: 'get',
          success: function(data) {
              console.log(data);
             $("select[name='product_id'").html('');
            $("select[name='product_id'").html(data.options);

          }
      });
  });


    });
</script>
