@extends('frontEnd.layout')
@section('content')


    <!-- START Page Map Title-->
    <div class="page_title parallax-window" data-parallax="scroll" data-image-src="{{url("frontEnd")}}/assets/images/banner/banner-1.png">
        <h1>Checkout </h1>
    </div>


@endsection
