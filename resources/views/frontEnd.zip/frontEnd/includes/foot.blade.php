



<script src="{{ URL::to('frontEnd/assets/js/jquery-3.4.1.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/popper.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/bootstrap.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/bootstrap-select.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/slick.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/jquery.nicescroll.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/parallax.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ URL::to('frontEnd/assets/js/script.js') }}"></script>
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.11.4/build/alertify.min.js"></script>



<script !src="">
    $(document).ready(function () {

        /**
         * add to fav
         *
         *
         */
        $('.aaf').on("click",function(){
            var product_id =  $(this).attr("data-id");
            // alert(""+product_id);
            var id = "{{ @Auth::user()->id }}";
            if ( id == "") {
                // alert((id));btn_style2
                alertify.error("You Need to Login !");
                window.location.href = '{{url('login/we')}}';
            }else

            $.ajax({
                type:'POST',
                url:'{{url('fav')}}'+"/"+ product_id,
                data:{_token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
               console.log(msg.data);
                    alertify.success(msg.ok);
                    location.reload(true);

                }
            });
            //post code
        });



        /**
         * add to cart
         *
         *
         */


        $('.add_to_cart').on("click",function(){
            var product_id =  $(this).attr("data_id");
            var id = "{{ @Auth::user()->id }}";

            if ( id == "") {
                // alert((id));
                alertify.error("You Need to Login !");
                window.location.href = '{{url('login/we')}}';
            }else

                $.ajax({
                type:'POST',
                url:'{{url('cart')}}'+"/"+ product_id,
                data:{_token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
                    console.log(msg.data);
                    alertify.success(msg.ok);
                    location.reload(true);

                }
            });
            //post code
        });

        /**
         * add to cart
         *
         *
         */


        $('.btn_cart_add').on("click",function(){
            // alert("dsds");
            var product_id =  $(this).attr("data_id");
            // alert(""+product_id);
            var id = "{{ @Auth::user()->id }}";

            if ( id == "") {
                // alert((id));
                alertify.error("You Need to Login !");
                window.location.href = '{{url('login/we')}}';
            }else

                $.ajax({
                type:'POST',
                url:'{{url('cart')}}'+"/"+ product_id,
                data:{_token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
                    console.log(msg.data);
                    alertify.success(msg.ok);
                    location.reload(true);

                }
            });
            //post code
        });

        /**
         * remove to cart
         *
         *
         */


        $('.trash').on("click",function(){
            var product_id =  $(this).attr("dataid");
            // alert(""+product_id);
            var id = "{{ @Auth::user()->id }}";

            if ( id == "") {
                // alert((id));
                alertify.error("You Need to Login !");
                window.location.href = '{{url('login/we')}}';
            }else

                $.ajax({
                type:'POST',
                url:'{{url('remove/cart')}}'+"/"+ product_id,
                data:{_token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
                    console.log(msg.data);
                    alertify.success(msg.ok);
                    location.reload(true);

                }
            });
            //post code
        });


        /**
         * min to cart
         *
         *
         */
        $('.minus').on("click",function(){
            var product_id =  $(this).attr("dataid_min");
            // alert(""+product_id);
            var id = "{{ @Auth::user()->id }}";

            if ( id == "") {
                // alert((id));
                alertify.error("You Need to Login !");
                window.location.href = '{{url('login/we')}}';
            }else

                $.ajax({
                type:'POST',
                url:'{{url('min/cart')}}'+"/"+ product_id,
                data:{_token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
                    console.log(msg.data);
                    alertify.success(msg.ok);
                    location.reload(true);

                }
            });
            //post code
        });

        /**
         * max to cart
         *
         *
         */
        $('.plus').on("click",function(){
            var product_id =  $(this).attr("dataid_plus");
            // alert(""+product_id);
            var id = "{{ @Auth::user()->id }}";

            if ( id == "") {
                // alert((id));
                alertify.error("You Need to Login !");
                window.location.href = '{{url('login/we')}}';
            }else

                $.ajax({
                type:'POST',
                url:'{{url('plus/cart')}}'+"/"+ product_id,
                data:{_token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
                    console.log(msg.data);
                    alertify.success(msg.ok);
                    location.reload(true);

                }
            });
        });
 /**
         * max to cart
         *
         *
         */
        $('#rang_price').on("click",function(){
            var price =  $(this).val();
            var product_id =  $(this).attr("data_id");
            var max =  $(this).attr("max");

            // alert(""+max);
            window.location.href = '{{url("products")}}'+'/'+product_id+'/'+'type='+'/'+'stand'+'/'+'style'+'/'+price+'/'+max;

        });


        /**
         * subscribe
         *
         *
         */
        $('.btn_style2').on("click",function(){
            var email =  $(".input_subscribe").val();

            $.ajax({
                type:'POST',
                url:'{{url('subscribe/send')}}',
                data:{
                    email:email,
                    _token: "{{ csrf_token() }}"
                },
                success: function( msg ) {
                    // console.log(msg.errors.email["0"]);
                    if(msg.errors != ""){
                        alertify.error(msg.errors.email["0"]);
                    }
                    console.log(msg);
                        alertify.success(msg.ok);
                        $(this).val('');


                }
            });
        });


        /**
         * star5
         *
         *
         */
        $('#star5').on("click",function(){
            var star =  $("#star5").val();
            var order_id =  $(this).attr("data_id");
            $.ajax({
                type:'POST',
                url:'{{url('rate/create')}}',
                data:{
                    star:star,
                    order_id:order_id,
                    _token: "{{ csrf_token() }}",
                },
                success: function( msg ) {
                    console.log(msg);
                        alertify.success(msg.ok);
                }
            });
        });
        /**
         * star4
         *
         *
         */
        $('#star4').on("click",function(){
            var star =  $("#star4").val();
            var order_id =  $(this).attr("data_id");
            $.ajax({
                type:'POST',
                url:'{{url('rate/create')}}',
                data:{
                    star:star,
                    order_id:order_id,
                    _token: "{{ csrf_token() }}",
                },
                success: function( msg ) {
                    console.log(msg);
                        alertify.success(msg.ok);
                }
            });
        });
        /**
         * star3
         *
         *
         */
        $('#star3').on("click",function(){
            var star =  $("#star3").val();
            var order_id =  $(this).attr("data_id");
            $.ajax({
                type:'POST',
                url:'{{url('rate/create')}}',
                data:{
                    star:star,
                    order_id:order_id,
                    _token: "{{ csrf_token() }}",
                },
                success: function( msg ) {
                    console.log(msg);
                        alertify.success(msg.ok);
                }
            });
        });
        /**
         * star2
         *
         *
         */
        $('#star2').on("click",function(){
            var star =  $("#star2").val();
            var order_id =  $(this).attr("data_id");
            $.ajax({
                type:'POST',
                url:'{{url('rate/create')}}',
                data:{
                    star:star,
                    order_id:order_id,
                    _token: "{{ csrf_token() }}",
                },
                success: function( msg ) {
                    console.log(msg);
                        alertify.success(msg.ok);
                }
            });
        });

        /**
         * star1
         *
         *
         */
        $('#star1').on("click",function(){
            var star =  $("#star1").val();
            var order_id =  $(this).attr("data_id");
            $.ajax({
                type:'POST',
                url:'{{url('rate/create')}}',
                data:{
                    star:star,
                    order_id:order_id,
                    _token: "{{ csrf_token() }}",
                },
                success: function( msg ) {
                    console.log(msg);
                        alertify.success(msg.ok);
                }
            });
        });

        /**
         * action_delete
         *
         *
         */
        $('.action_del').on("click",function(){
            var order_id =  $(this).attr("order_id");
            // alert(order_id);
            $.ajax({
                type:'POST',
                url:'{{url('delete/order')}}',
                data:{
                    order_id:order_id,
                    _token: "{{ csrf_token() }}",
                },
                success: function( msg ) {
                    console.log(msg);
                        alertify.success(msg.ok);
                }
            });
        });




    });

</script>
