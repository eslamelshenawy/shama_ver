<?php

namespace App\Http\Controllers\API;

use App\Banner;
use App\category;
use App\product;
use App\subcategory;
use App\FavouriteProduct;
use App\User;
use App\Order;
use App\Topic;
use App\Rate;
use App\Cart;
use App\WebmasterBanner;
use App\WebmasterSection;
use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use Validator;

class ApiController extends   BaseController
{

    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function categories(Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
        ]);


        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        if($request->lang == "en"){
            $category=  category::select("name_en as name","photo","id")->get();
        }else{

            $category=  category::select("name_heb as name","photo","id")->get();
        }
        return $this->sendResponse($category, 'All Categories');
    }


    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function subcategories(Request $request){
//        dd($request->all());
        $validator = Validator::make($request->all(),[
            'lang' => 'required',
            'category_id' => 'required',
        ]);


        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }


        if($request->lang == "en"){
            $subcategory=  subcategory::where('category_id',$request->category_id)->select("name_en as name","photo","id")->get();
        }else {
            $subcategory=  subcategory::where('category_id',$request->category_id)->select("name_heb as name","photo","id")->get();
        }
        return $this->sendResponse($subcategory, 'All Categories');
    }

    /**
     * success response method.
     *
     * @return products
     */
    public function products(Request $request){

        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'subcategory_id' => 'required',
        ]);


        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        if($request->lang == "en"){

            $products_rate=  product::with("images","standardgold","rate","favourite_product","promo_code")
                ->orderBy('id', 'desc')->get();

            if($products_rate->isEmpty()){
                return $this->sendResponse($details="", 'Not found  products');
            }

            $total = 0;
            for ($i = 0; $i<count($products_rate); $i++)
            {

                $imags=@$products_rate[$i]->images[$i];
                $standardgold=@$products_rate[$i]->standardgold[0];
                $rate=@$products_rate[$i]->rate[$i];
                $favourite_product=@$products_rate[$i]->favourite_product;
                $promo_code=@$products_rate[$i]->promo_code;
                $details [] =
                    [
                        'id'=>@$products_rate[$i]->id,
                        'name'=>@$products_rate[$i]->name_en,
                        'details'=>@strip_tags($products_rate[$i]->details_en),
                        'photo'=>@$products_rate[$i]->photo,
                        'SalesPrice'=>@$products_rate[$i]->price,
                        'OriginalPrice'=>@$products_rate[$i]->special_price,
                        'offer'=>@$promo_code->amount == null ? "0" : "1",
                        'caliber'=>@$products_rate[$i]->topic_name($standardgold->standard_gold,"en") ,
                        'favorite'=>@$favourite_product->status == null ? "0" : "1",
                    ];
//                dd($details);

            }



        }else {

            $products_rate=  product::with("images","standardgold","rate","favourite_product","promo_code")
                ->orderBy('id', 'desc')->get();
            if($products_rate->isEmpty()){
                return $this->sendResponse($details="", 'Not found  products');
            }

            $total = 0;
            for ($i = 0; $i<count($products_rate); $i++)
            {

                $imags=@$products_rate[$i]->images[$i];
                $standardgold=@$products_rate[$i]->standardgold[0];
                $rate=@$products_rate[$i]->rate[$i];
                $favourite_product=@$products_rate[$i]->favourite_product;
                $promo_code=@$products_rate[$i]->promo_code;

                $details [] =
                    [
                        'id'=>@$products_rate[$i]->id,
                        'name'=>@$products_rate[$i]->name_heb,
                        'details'=>@strip_tags($products_rate[$i]->details_il),
                        'photo'=>@$products_rate[$i]->photo,
                        'SalesPrice'=>@$products_rate[$i]->price,
                        'OriginalPrice'=>@$products_rate[$i]->special_price,
                        'offer'=>@$promo_code->amount == null ? "0" : "1",
                        'caliber'=>@$products_rate[$i]->topic_name($standardgold->standard_gold,"ar") ,
                        'favorite'=>@$favourite_product->status == null ? "0" : "1",
                    ];

            }

        }

        return $this->sendResponse($details, 'All Products');
    }

    /**
     * success response method.
     *
     * @return products_detalis
     */
    public function products_detalis(Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'product_id' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        if($request->lang == "en"){
            $products=  product::where("id",$request->product_id)->with("images","rate")
                ->select("name_en as name","details_en as details","photo","price as SalesPrice","special_price as OriginalPrice","id")->get();
        }else {
            $products=  product::where("id",$request->product_id)->with("images","rate")
                ->select("name_heb as name","details_en as details","photo","price as SalesPrice","special_price as OriginalPrice","id")->get();
        }
        return $this->sendResponse($products, ' Product details ');
    }

    /**
     * success response method.
     *
     * @return Banner
     */

    public function Banner (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        if($request->lang == "en"){
            $Banners = Banner::select("file_en as image","id")->where('section_id', '=', '1')->get();
        }else {
            $Banners = Banner::select("file_ar as image","id")->where('section_id', '=', '1')->get();
        }
        return $this->sendResponse($Banners, 'Banner');
    }


    /**
     * success response method.
     *
     * @return style
     */

    public function style (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        if($request->lang == "en"){
            $styles = Topic::select("topics.title_en as style_name","topics.id as style_id","topics.photo_file as style_image")->where('webmaster_id', '=', '16')->get();
        }else {
            $styles = Topic::select("topics.title_il as style_name","topics.id as style_id","topics.photo_file as style_image")->where('webmaster_id', '=', '16')->get();
        }
        return $this->sendResponse($styles, 'style');
    }

    /**
     * success response method.
     *
     * @return style
     */

    public function style_id (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'product_id' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        if($request->lang == "en"){
            $styles = Topic::select("title_en as title","photo_file")->join("products","products.style_id","=","topics.id")
                ->where("products.id",$request->product_id)
                ->where('webmaster_id', '=', '16')->get();
        }else {
            $styles = Topic::select("title_il as title","photo_file")->join("products","products.style_id","=","topics.id")
                ->where("products.id",$request->product_id)
                ->where('topics.webmaster_id', '=', '16')->select("topics.title_il as style_name","topics.id as style_id","topics.photo_file as style_image")->get();
        }
        return $this->sendResponse($styles, 'style');
    }
    /**
     * success response method.
     *
     * @return style
     */

    public function standard_gold (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        if($request->lang == "en"){
            $styles = Topic::select("title_en as name","photo_file as image","id")->where('webmaster_id', '=', '15')->get();
        }else {
            $styles = Topic::select("title_il as name","photo_file as image","id")->where('webmaster_id', '=', '15')->get();
        }
        return $this->sendResponse($styles, 'style');
    }

    /**
     * success response method.
     *
     * @return style
     */

    public function standard_gold_product (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'product_id' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        if($request->lang == "en"){
            $standard = Topic::select("title_en as title","photo_file")->join("products","products.standard_gold","=","topics.id")
                ->where("products.id",$request->product_id)
                ->where('webmaster_id', '=', '15')
                ->select("topics.title_il as name","topics.id as id","products.price as price")->get();
        }else {
            $standard = Topic::select("title_il as title","photo_file")->join("products","products.standard_gold","=","topics.id")
                ->where("products.id",$request->product_id)
                ->where('topics.webmaster_id', '=', '15')->
                select("topics.title_il as name","topics.id as id","products.price as price")->get();

        }
        return $this->sendResponse($standard, 'standard_gold_product');
    }

    /**
     * success response method.
     *
     * @return size
     */

    public function size (Request $request){
        $validator = Validator::make($request->all(),[
            'lang' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        if($request->lang == "en"){
            $sizes = Topic::select("title_en as title","photo_file")->where('webmaster_id', '=', '18')->get();
        }else {
            $sizes = Topic::select("title_il as title","photo_file")->where('webmaster_id', '=', '18')->get();
        }
        return $this->sendResponse($sizes, 'style');
    }

    /**
     * success response method.
     *
     * @return size
     */

    public function size_product_id (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'product_id' => 'required',

        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        if($request->lang == "en"){
            $sizes = Topic::select("products.id as id","topics.size as size")->join("products","products.size_id","=","topics.id")
                ->where("products.id",$request->product_id)->where('webmaster_id', '=', '18')->get();
        }else {
            $sizes = Topic::select("products.id as id","topics.size as size")->join("products","products.size_id","=","topics.id")
                ->where("products.id",20)->where('topics.webmaster_id', '=', '18')->get();


        }
        return $this->sendResponse($sizes, 'style');
    }

    /**
     * success response method.
     *
     * @return fave_product
     */

    public function fave_product (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user_id=$request->user()->id;

        if($request->lang == "en"){

            $products_fav=  FavouriteProduct::where("favourite_products.user_id",$user_id)->where("status","1")->
            with("fav_product")
                ->orderBy('id', 'desc')->get();

            if($products_fav->isEmpty()){
                return $this->sendResponse($details="", 'Not found Favourit products');
            }
            $total = 0;
            for ($i = 0; $i<count(@$products_fav); $i++)
            {
                $details [] =
                    [
                        'id'=>@$products_fav[$i]->fav_product->id,
                        'name'=>@$products_fav[$i]->fav_product->name_en,
                        'details'=>@strip_tags($products_fav[$i]->fav_product->details_en),
                        'photo'=>@$products_fav[$i]->fav_product->photo,
                        'SalesPrice'=>@$products_fav[$i]->fav_product->price,
                        'OriginalPrice'=>@$products_fav[$i]->fav_product->special_price,
                        // 'imags'=>@$imags->file == null ? "0" : "1",
                        'offer'=>@$products_fav[$i]->fav_product->promo_code_amount($products_fav[$i]->fav_product->id) == null ? "0" : "1",
                        'favorite'=>@$products_fav[$i]->fav_product->favourite_product_status($products_fav[$i]->fav_product->id) == null ? "0" : "1",
                        'caliber'=>$products_fav[$i]->fav_product->topic_name($products_fav[$i]->fav_product->standard_gold,"ar"),
                    ];

            }

        }else {

            $products_fav=  FavouriteProduct::where("favourite_products.user_id",$user_id)->where("status","1")->
            with("fav_product")
                ->orderBy('id', 'desc')->get();
            if($products_fav->isEmpty()){
                return $this->sendResponse($details="", 'Not found Favourit products');
            }

            $total = 0;
            for ($i = 0; $i<count($products_fav); $i++)
            {
                $details [] =
                    [
                        'id'=>@$products_fav[$i]->fav_product->id,
                        'name'=>@$products_fav[$i]->fav_product->name_heb,
                        'details'=>@strip_tags($products_fav[$i]->fav_product->details_il),
                        'photo'=>@$products_fav[$i]->fav_product->photo,
                        'SalesPrice'=>@$products_fav[$i]->fav_product->price,
                        'OriginalPrice'=>@$products_fav[$i]->fav_product->special_price,
                        // 'imags'=>@$imags->file == null ? "0" : "1",
                        'offer'=>@$products_fav[$i]->fav_product->promo_code_amount($products_fav[$i]->fav_product->id) == null ? "0" : "1",
                        'favorite'=>@$products_fav[$i]->fav_product->favourite_product_status($products_fav[$i]->fav_product->id) == null ? "0" : "1",
                        'caliber'=>$products_fav[$i]->fav_product->topic_name($products_fav[$i]->fav_product->standard_gold,"ar"),
                    ];
            }
        }
        return $this->sendResponse($details, 'All products');
    }

    /**
     * success response method.
     *
     * @return add_fave_product
     */

    public function add_fave_product (Request $request){
        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'product_id' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user_id=$request->user()->id;
        $product_id=$request->product_id;

        $product_fav= FavouriteProduct::where("product_id",$product_id)->where("user_id",$user_id)->first();
        if (empty($product_fav)){
            $product_fav=new FavouriteProduct;
            $product_fav->status= 1;
            $product_fav->user_id= $user_id;
            $product_fav->product_id= $request->product_id;
            $product_fav->save();

        }else{
            $status=$product_fav->status;
            if($status == 1){
                $product_fav_id=$product_fav->id;
                $product_fav= FavouriteProduct::find($product_fav_id);
                $product_fav->status= 0;
                $product_fav->save();
                return $this->sendResponse($product_fav, 'successfully remove Fav');

            }else{
                $product_fav_id=$product_fav->id;
                $product_fav= FavouriteProduct::find($product_fav_id);
                $product_fav->status= 1;
                $product_fav->save();
                return $this->sendResponse($product_fav, 'successfully Add Fav');

            }



        }
    }


    /**
     * success response method.
     *
     * @return Banner
     */

    public function filter (Request $request)
    {
        $q = product::where('price','<',$request->min_price)->get();

    }


    /**
     * success response method.
     *
     * @return edit_profile
     */

    public function edit_profile (Request $request){

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'lang' => 'required',

        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user_id=$request->user()->id;
        $users=User::find($user_id);
        $users->name= $request->name;
        $users->email= $request->email;
        $users->phone= $request->phone;
        $users->password= $request->password;
        $users->save();
        return $this->sendResponse($users, 'User modification successfully.');


    }


    /**
     * success response method.
     *
     * @return edit_profile
     */

    public function add_rate_comment (Request $request){

        $validator = Validator::make($request->all(), [
            'product_id' => 'required',
            'stars' => 'required',
            'comment' => 'required',
            'lang' => 'required',

        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user_id=$request->user()->id;
        $rates=Rate::where("user_id",$user_id)->where("product_id",$request->product_id)->first();
        if (empty($rates)){
            $rates=new Rate;

            $rates->product_id= $request->product_id;
            $rates->stars= $request->stars;
            $rates->comment= $request->comment;
            $rates->user_id= $user_id;
            $rates->save();

        }
        else{
            $rates=Rate::find($rates->id);
            $rates->product_id= $request->product_id;
            $rates->stars= $request->stars;
            $rates->comment= $request->comment;
            $rates->user_id= $user_id;
            $rates->save();

        }
        return $this->sendResponse($rates,'User rate successfully.');


    }

    /**
     * success response method.
     *
     * @return edit_profile
     */

    public function profile (Request $request){


        $user_id=$request->user()->id;
        $users=User::find($user_id);
        return $this->sendResponse($users, 'User Profile.');


    }

    /**
     * success response method.
     *
     * @return add_cart
     */

    public function add_cart (Request $request){

        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'product_id' => 'required',
            'qty' => 'required',
            'standard_gold_id' => 'required',
            'size_id' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        $user_id=$request->user()->id;
        $cart=Cart::where("user_id",$user_id)->where("product_id",$request->product_id)->first();
        if(empty($cart)){
            $cart=new Cart;
            $cart->product_id= $request->product_id;
            $cart->qty= $request->qty;
            $cart->user_id= $user_id;
            $cart->standard_gold_id= $request->standard_gold_id;
            $cart->size_id= $request->size_id;
            $cart->save();
        }
        else{
            $cart=Cart::find($cart->id);
            $cart->product_id= $request->product_id;
            $cart->qty= $request->qty;
            $cart->user_id= $user_id;
            $cart->standard_gold_id= $request->standard_gold_id;
            $cart->size_id= $request->size_id;
            $cart->save();
        }

        return $this->sendResponse( $cart,'User add Cart successfully.');


    }


    /**
     * success response method.
     *
     * @return add_cart
     */

    public function plusCart(Request $request){

        $validator = Validator::make($request->all(), [
            'lang' => 'required',
//            'product_id' => 'required',
//            'qty' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        $user_id=$request->user()->id;
        $cart = Cart::where('user_id',$user_id)->first();

        if (empty($cart))
        {
            return $this->sendResponse('cart is empty','',400);
        }
        elseif ( $cart->qty == 0)
        {
            \DB::table('carts')
                ->where('user_id','=',$user_id)
                ->delete();

            return $this->sendResponse('delete all cart success','',200);

        }
        else
        {
            $action = Cart::
            where('user_id','=',$user_id)->get();
            foreach ($action as  $cart){
                $cart->qty=$cart->qty + 1;
                $cart->save();
            }
            if ( $cart->save())
            {
                return $this->sendResponse('plus qty cart success','',200);
            }
            else
            {
                return $this->sendResponse('please try again','',200);
            }


        }




    }

    /**
     * success response method.
     *
     * @return add_cart
     */

    public function minCart(Request $request){

        $validator = Validator::make($request->all(), [
            'lang' => 'required',
//            'product_id' => 'required',
//            'qty' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        $user_id=$request->user()->id;
        $cart = Cart::where('user_id',$user_id)->first();

        if (empty($cart))
        {
            return $this->sendResponse('cart is empty','',400);
        }
        elseif ( $cart->qty == 0)
        {
                \DB::table('carts')
                    ->where('user_id','=',$user_id)
                    ->delete();

                return $this->sendResponse('delete all cart success','',200);

        }
        else
        {
                $action = Cart::
                    where('user_id','=',$user_id)->get();
                foreach ($action as  $cart){
                    $cart->qty=$cart->qty-1;
                    $cart->save();
                }
                if ( $cart->save())
                {
                    return $this->sendResponse('min qty cart success','',200);
                }
                else
                {
                    return $this->sendResponse('please try again','',200);
                }


        }



    }

    /**
     * success response method.
     *
     * @return cart
     */

    public function cart (Request $request){

        $validator = Validator::make($request->all(), [
            'lang' => 'required',

        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user_id=$request->user()->id;
        if($request->lang == "en") {
            $cart = Cart::where("user_id", $user_id)->leftjoin("products", "products.id", "=", "carts.product_id")
                ->select("products.id as id", "products.name_en as name","carts.qty","products.price as price")->get();
        }else{
            $cart = Cart::where("user_id", $user_id)->leftjoin("products", "products.id", "=", "carts.product_id")
                ->select("products.id as id", "products.name_heb as name","carts.qty","products.price as price")->get();

        }
        $total = 0;
        for ($i = 0; $i<count($cart); $i++)
        {
            $total +=  $cart[$i]->price* $cart[$i]->qty ;
            $details [] =
                [
                    'id'=>$cart[$i]->id,
                    'name'=>$cart[$i]->name,
                    'qty'=>$cart[$i]->qty,
                    'price'=>$cart[$i]->price,
                    'totalPrice' =>$total,
                ];

        }


        return $this->sendResponse($details ,'User add Cart successfully.');


    }

    /**
     * success response method.
     *
     * @return order
     */

    public function order (Request $request){


        $user_id=$request->user()->id;
        $orders=Order::where("user_id","$user_id")->get();
        return $this->sendResponse($orders, 'User orders.');


    }

    /**
     * success response method.
     *
     * @return order_details
     */

    public function order_details (Request $request){

        $validator = Validator::make($request->all(), [
            'lang' => 'required',
            'order_id' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }
        $user_id=$request->user()->id;
        $order_id=$request->order_id;
        if($request->lang == "en") {
            $order_details = Order::where("orders.id",$order_id)->join("products", "products.id", "=", "orders.product_id")->
            select("products.name_en as name", "products.id as product id","orders.total_price as price")->get();
        }else{
            $order_details = Order::where("orders.id",$order_id)->join("products", "products.id", "=", "orders.product_id")->
            select("products.name_heb as name", "products.id as product id","orders.total_price as price")->get();
        }
        return $this->sendResponse($order_details, 'User orders details.');


    }







}
